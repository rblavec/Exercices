﻿using System;

namespace POO
{
	public class Carte
    {
        public long NumCarte { get; set; }
        public long NumCompte { get; set; }
        public DateTime DateExpiration { get; set; }
        public int CodeVérif { get; set; }
        public int CodeSecret { get; set; }
    }
}
