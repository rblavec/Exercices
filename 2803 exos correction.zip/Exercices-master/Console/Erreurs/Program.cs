﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Erreurs
{
    class Program
    {
        static void Main(string[] args)
        {
            string chemin = @"..\..\DonnéesMétéoParis.txt";
            ChargerFichier(chemin);
        }

        static void ChargerFichier(string chemin)
        {
            // Chargement du contenu du fichier dans un tableau de chaînes
            string[] lignes = null;
            try
            {
                lignes = File.ReadAllLines(chemin);

                double tempMin = double.MaxValue;
                double tempMax = double.MinValue;
                DateTime moisTempMin = DateTime.MinValue;
                DateTime moisTempMax = DateTime.Today;

                double tMin = 0, tMax = 0;
                DateTime mois = DateTime.Today;
                try
                {
                    for (int l = 1; l < lignes.Length; l++)
                    {
                        AnalyserLigne(lignes[l], out moisTempMin, out tempMin, out moisTempMax, out tempMax);
                    }
                }
                catch (FormatException)
                {
                    
                }

                Console.WriteLine("Mois le plus froid : {0} ({1}°C)", moisTempMin, tempMin);
                Console.WriteLine("Mois le plus chaud : {0} ({1}°C)", moisTempMax, tempMax);
            }
            catch (FileNotFoundException)
            {

                Console.WriteLine("Fichier nom trouvé : {0}", chemin);
            }
            catch (Exception)
            {
                Console.WriteLine("Erreur avec le fichier {0}", chemin);
            }
            Console.ReadKey();
        }


        static void AnalyserLigne(string ligne,
                                  out DateTime moisTempMin,
                                  out double tempMin,
                                  out DateTime moisTempMax,
                                  out double tempMax)
        {
            string[] valeurs = ligne.Split('\t');

            tempMin = double.MaxValue;
            tempMax = double.MinValue;
            moisTempMin = DateTime.Today;
            moisTempMax = DateTime.Today;

            DateTime mois = DateTime.Parse(valeurs[0]);
            double tMin = double.Parse(valeurs[1]);
            double tMax = double.Parse(valeurs[2]);

            if (tMin < tempMin)
            {
                tempMin = tMin;
                moisTempMin = mois;
            }

            if (tMax > tempMax)
            {
                tempMax = tMax;
                moisTempMax = mois;
            }
        }
    }
}
