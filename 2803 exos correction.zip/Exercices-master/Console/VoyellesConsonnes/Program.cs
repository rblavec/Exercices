﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoyellesConsonnes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Saisissez un mot");
            string mot = Console.ReadLine();

            int nbVoyelles, nbConsonnes;
            CompterVoyellesConsonnes(mot, out nbVoyelles, out nbConsonnes);
            Console.WriteLine("Le mot {0} comporte {1} voyelles et {2} consonnes", mot, nbVoyelles, nbConsonnes);
            Console.ReadKey();
        }

        static void CompterVoyellesConsonnes(string mot, out int nbVoy, out int nbCons)
        {
            nbVoy = 0;

            mot = mot.ToUpper();
            for (int i=0; i<mot.Length; i++)
            {
                if (mot[i] == 'A' || mot[i] == 'E' || mot[i] == 'I' || mot[i] == 'O' || mot[i] == 'U' || mot[i] == 'Y')
                {
                    nbVoy++;
                }
            }
            nbCons = mot.Length - nbVoy;
        }
    }
}
