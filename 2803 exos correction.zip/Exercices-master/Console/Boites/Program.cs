﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boites
{
    class Program
    {
        static void Main(string[] args)
        {
            Etiquette etqDest = new Etiquette
            {
                Couleur = Couleurs.Blanc,
                Format = Formats.L,
                Texte = "Adresse"
            };

            Etiquette etqFragile = new Etiquette
            {
                Couleur = Couleurs.Rouge,
                Format = Formats.S,
                Texte = "FRAGILE"
            };

            Boite b1 = new Boite(30, 60, 20);
            Boite b2 = new Boite(30, 40, 50, Matières.Plastique);
            b2.Etiqueter(etqDest, etqFragile);

            Console.WriteLine("Nombre de boîtes : {0}", Boite.Compteur);

            b1.Etiqueter("M.Dupont Jean", true);

            //Console.WriteLine("Boite de volume {0} cm3, de couleur {1} et en {2}",
            //    b1.Volume, b1.Couleur, b1.Matière);

            Console.ReadKey();
        }
    }

}
