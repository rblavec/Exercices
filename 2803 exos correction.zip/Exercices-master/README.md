Le dossier Console contient la solution Visual Studio et tous les projets C# en mode console
NB/ Le projet POO contient les exemples du compte bancaire et du distributeur de boissons

Le dossier UML contient le fichier eap (Enterprise Architect) et les diagrammes sous formes d'images
